import {randomUUID} from 'node:crypto';
import {githubId, repositoryCoordinates, canonicalJSON, contentIdentity, prepareCustodyManifest, publishCustody} from './index.mjs';

const same = (a, b) => canonicalJSON(a) === canonicalJSON(b);
const hash = v => typeof v === 'string' && /^[a-f0-9]{64}$/.test(v);
const name = v => typeof v === 'string' && /^[a-zA-Z0-9_-]{1,80}$/.test(v);
const sha = v => typeof v === 'string' && /^[a-f0-9]{40}$/.test(v);
const exact = (v, keys) => v && same(Object.keys(v).sort(), keys.split(' ').sort());
const fail = () => {throw Error('operations:identity');};
async function bounded(work, signal) {
  if (signal.aborted) throw Error('operations:cancelled');
  let abort;
  try {
    return await Promise.race([work, new Promise((_, reject) => {
      abort = () => reject(Error('operations:cancelled')); signal.addEventListener('abort', abort, {once:true});
    })]);
  } finally {signal.removeEventListener('abort', abort);}
}
const unknown = (refs = {}, reason = 'readback') => ({outcome: 'unknown', continuation: false, refs, reason});

/** Construct the exact supported HTTP request; callers cannot supply endpoints/predicates. */
export function controlledIntent(input) {
  const v = JSON.parse(canonicalJSON(input));
  if (!exact(v, 'version kind correlation source binding target payload') || v.version !== 1
      || !['dispatch', 'pr', 'merge', 'close', 'label'].includes(v.kind) || !name(v.correlation)) fail();
  const b = v.binding;
  if (!exact(b, 'repository repositoryId issueId number cycle scopeHash shapeHash authorization runId attempt candidate base head'
      + (v.kind === 'merge' ? ' baseRef' : ''))
      || typeof b.repository !== 'string') fail();
  const parts = b.repository.split('/');
  if (parts.length !== 2 || repositoryCoordinates(...parts).key !== b.repository) fail();
  for (const key of ['repositoryId', 'number', 'runId', 'attempt']) githubId(b[key]);
  for (const key of ['scopeHash', 'shapeHash', 'authorization']) if (!hash(b[key])) fail();
  if (typeof b.issueId !== 'string' || !/^[A-Za-z0-9_=-]{1,256}$/.test(b.issueId)
      || !name(b.cycle) || b.candidate !== null && !hash(b.candidate)
      || b.base !== null && !sha(b.base) || b.head !== null && !sha(b.head)) fail();
  if (!exact(v.source, 'request event repositoryId runId attempt actorId') || !name(v.source.request) || !name(v.source.event)) fail();
  for (const key of ['repositoryId', 'runId', 'attempt', 'actorId']) githubId(v.source[key]);
  if (!exact(v.target, 'id number workflow') || !v.payload || typeof v.payload !== 'object' || Array.isArray(v.payload)) fail();
  githubId(v.target.id);
  const p = v.payload, t = v.target;
  if (['close', 'label'].includes(v.kind) && (t.number !== b.number || t.workflow !== null)) fail();
  if (['pr', 'merge'].includes(v.kind)) {
    if (!sha(b.head) || !sha(b.base) || !hash(b.candidate)) fail();
    if (v.kind === 'merge') githubId(t.number);
  }
  if (v.kind === 'dispatch') {
    if (t.workflow !== t.id || t.number !== null || !exact(p, 'ref inputs') || !sha(p.ref)
        || !p.inputs || typeof p.inputs !== 'object' || Array.isArray(p.inputs)
        || Object.values(p.inputs).some(x => typeof x !== 'string')
        || p.inputs.nibfin_correlation !== v.correlation) fail();
  } else if (v.kind === 'close') {
    githubId(t.number);
    if (!exact(p, 'state state_reason') || p.state !== 'closed' || p.state_reason !== 'completed') fail();
  } else if (v.kind === 'label') {
    githubId(t.number);
    if (!exact(p, 'labels') || !Array.isArray(p.labels) || !p.labels.length || p.labels.some(x => !name(x))
        || new Set(p.labels).size !== p.labels.length) fail();
  } else if (v.kind === 'merge') {
    if (typeof b.baseRef !== 'string' || !/^[a-zA-Z0-9_./-]{1,128}$/.test(b.baseRef)
        || b.baseRef.includes('..') || b.baseRef.includes('//') || b.baseRef.startsWith('/') || b.baseRef.endsWith('/')
        || t.workflow !== null || !exact(p, 'sha merge_method') || p.sha !== b.head
        || !['merge', 'squash', 'rebase'].includes(p.merge_method)) fail();
  } else {
    // Creation only. Updates are deliberately outside this version's exposed PR contract.
    if (t.number !== null || t.workflow !== null || t.id !== b.repositoryId
        || !exact(p, 'title body head base') || typeof p.title !== 'string' || !p.title.trim()
        || p.title.length > 256 || typeof p.body !== 'string'
        || !p.body.endsWith(`\n<!-- nibfin-operation:${v.correlation} -->`)
        || ![p.head, p.base].every(x => typeof x === 'string' && /^[a-zA-Z0-9_/-]{1,128}$/.test(x)
          && !x.includes('..') && !x.includes('//'))) fail();
  }
  return v;
}
function requestFor(v) {
  const root = `/repos/${v.binding.repository}`, t = v.target;
  return {method: ({dispatch: 'POST', pr: 'POST', merge: 'PUT', close: 'PATCH', label: 'POST'})[v.kind],
    endpoint: root + ({dispatch: `/actions/workflows/${t.workflow}/dispatches`, pr: '/pulls',
      merge: `/pulls/${t.number}/merge`, close: `/issues/${t.number}`, label: `/issues/${t.number}/labels`})[v.kind],
    operation: v.kind, target: t.id, correlation: v.correlation, body: v.payload};
}
function custodyBinding(v, phase, source) {
  const b = v.binding;
  return {repository: b.repository, repositoryId: b.repositoryId, issueId: b.issueId, cycle: b.cycle,
    scopeHash: b.scopeHash, shapeHash: b.shapeHash, authorization: b.authorization,
    runId: source.runId, attempt: source.attempt, stage: 'candidate', result: `${phase}-${contentIdentity(v)}`, candidate: null};
}
/** Independent GETs only. Acknowledgment is never sufficient. */
async function observe(provider, v, signal) {
  const root = `/repos/${v.binding.repository}`, options = {operation: v.kind, correlation: v.correlation, target: v.target.id, signal};
  const read = async endpoint => {
    const r = await provider.request({...options, endpoint, method: 'GET'});
    if (r.outcome !== 'read' || signal?.aborted) throw Error('readback');
    return r;
  };
  const repo = await read(root);
  if (repo.data?.id !== v.binding.repositoryId || repo.data.full_name?.toLowerCase() !== v.binding.repository
      || repo.data.private !== false) throw Error('repository');
  let r;
  if (v.kind === 'dispatch' || v.kind === 'pr') {
    const path = v.kind === 'pr' ? `${root}/pulls` : `${root}/actions/workflows/${v.target.workflow}/runs`;
    const query = v.kind === 'pr' ? '?state=all&per_page=100' : '?event=workflow_dispatch&per_page=100';
    let total;
    const result = await provider.collection({...options, endpoint: path + query,
      ...(v.kind === 'dispatch' ? {envelope: 'workflow_runs', validate: d => {
        if (!Number.isSafeInteger(d?.total_count) || d.total_count < 0 || total !== undefined && total !== d.total_count) return false;
        total = d.total_count; return true;
      }} : {}), allowPage: p => p.split('?')[0] === path});
    if (result.outcome !== 'complete' || v.kind === 'dispatch' && result.data.length !== total) throw Error('pagination');
    const matchesEffect = d => v.kind === 'pr'
      ? d.body === v.payload.body && d.title === v.payload.title && d.head?.ref === v.payload.head
        && d.base?.ref === v.payload.base && d.head?.sha === v.binding.head && d.base?.sha === v.binding.base
        && d.base?.repo?.id === v.binding.repositoryId && d.head?.repo?.id === v.binding.repositoryId
      : d.workflow_id === v.target.id && d.event === 'workflow_dispatch' && d.head_sha === v.payload.ref
        && d.display_title === `nibfin-operation:${v.correlation}` && d.repository?.id === v.binding.repositoryId;
    const matches = result.data.filter(matchesEffect);
    if (matches.length !== 1) throw Error('ambiguous');
    r = await read(v.kind === 'pr' ? `${root}/pulls/${matches[0].number}` : `${root}/actions/runs/${matches[0].id}`);
    if (r.data?.id !== matches[0].id || !matchesEffect(r.data)
        || v.kind === 'pr' && r.data.number !== matches[0].number) throw Error('changed');
    return {effect: v.kind === 'pr' ? 'pr-created' : 'dispatch-run-observed', id: r.data.id,
      endpoint: v.kind === 'pr' ? `${root}/pulls/${matches[0].number}` : `${root}/actions/runs/${matches[0].id}`,
      observedAt: r.observedAt, identity: contentIdentity(r.data)};
  }
  if (v.kind === 'merge') {
    r = await read(`${root}/pulls/${v.target.number}`);
    const d = r.data;
    if (d.id !== v.target.id || String(d.number) !== v.target.number || d.base?.repo?.id !== v.binding.repositoryId
        || d.base?.ref !== v.binding.baseRef || d.base?.sha !== v.binding.base
        || d.head?.repo?.id !== v.binding.repositoryId || d.head?.sha !== v.binding.head
        || d.merged !== true || d.state !== 'closed' || !sha(d.merge_commit_sha)) throw Error('merge');
    const commit = await read(`${root}/commits/${d.merge_commit_sha}`);
    if (commit.data?.sha !== d.merge_commit_sha) throw Error('commit');
    return {effect: 'merged', id: d.id, mergeCommit: d.merge_commit_sha, baseRef: d.base.ref, base: d.base.sha,
      endpoint: `${root}/pulls/${v.target.number}`, observedAt: r.observedAt, identity: contentIdentity(d)};
  }
  r = await read(`${root}/issues/${v.target.number}`);
  const d = r.data;
  if (d.id !== v.target.id || d.node_id !== v.binding.issueId || String(d.number) !== v.binding.number
      || d.repository_url !== `https://api.github.com${root}` || d.pull_request) throw Error('issue');
  if (v.kind === 'close' && (d.state !== 'closed' || d.state_reason !== 'completed' || !d.closed_at)) throw Error('close');
  let labelsIdentity;
  if (v.kind === 'label') {
    // The Issue response can truncate labels: independently retrieve the full collection.
    const path = `${root}/issues/${v.target.number}/labels`;
    const labels = await provider.collection({...options, endpoint: path + '?per_page=100', allowPage: p => p.split('?')[0] === path});
    if (labels.outcome !== 'complete' || !v.payload.labels.every(x => labels.data.some(l => l.name === x))) throw Error('labels');
    labelsIdentity = contentIdentity(labels.data);
  }
  return {effect: v.kind === 'close' ? 'closed-completed' : 'labels-present', id: d.id,
    ...(labelsIdentity ? {labelsIdentity, labelsEndpoint: `${root}/issues/${v.target.number}/labels`} : {}),
    endpoint: `${root}/issues/${v.target.number}`, observedAt: r.observedAt, identity: contentIdentity(d)};
}
/**
 * All capabilities are trusted Core-owned. locate resolves the original request's
 * traceable custody references, or positively attests a new request. Never infer
 * newness from a missing artifact. Writes must use createAuthorizationBoundary.
 */
export function createControlledOperations({authorization, provider, custody, publication, locate, execution, timeoutMs = 30000} = {}) {
  if (typeof authorization?.request !== 'function' || typeof provider?.request !== 'function'
      || typeof provider?.collection !== 'function' || typeof custody?.retrieve !== 'function'
      || typeof publication !== 'function' || typeof locate !== 'function') throw Error('operations:capability');
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 86400000) throw Error('operations:timeout');
  if (!exact(execution, 'runId attempt')) fail();
  githubId(execution.runId); githubId(execution.attempt);
  execution = structuredClone(execution);
  async function recover(entry, v, phase, signal) {
    if (!exact(entry, 'ref source') || !exact(entry.source, 'runId attempt')) fail();
    githubId(entry.source.runId); githubId(entry.source.attempt);
    const r = await bounded(custody.retrieve({ref: entry.ref, expected: custodyBinding(v, phase, entry.source), signal}), signal);
    if (r.outcome !== 'retrieved') throw Error('custody');
    const value = JSON.parse(r.payloads.get('operation.json').toString());
    if (!same(value.intent, v) || value.phase !== phase || value.version !== 1) throw Error('binding');
    return value;
  }
  async function retain(v, phase, value, signal) {
    const expected = custodyBinding(v, phase, execution);
    const payloads = new Map([['operation.json', Buffer.from(canonicalJSON({version: 1, phase, intent: v, ...value}))]]);
    const manifest = prepareCustodyManifest(expected, payloads);
    const facilities = await bounded(publication({intent: v, phase, expected}), signal);
    const r = await publishCustody({...facilities, expected, manifest, payloads, custody,
      name: `${phase}-${contentIdentity(v)}-${randomUUID()}`, retentionDays: 7, signal});
    if (r.outcome !== 'retained') throw Error('retention');
    const entry = {ref:r.ref, source:structuredClone(execution)};
    await recover(entry, v, phase, signal);
    return entry;
  }
  async function execute(input, {signal: caller, retryAfterNoEffect = false} = {}) {
    const signal = AbortSignal.any([AbortSignal.timeout(timeoutMs), ...(caller ? [caller] : [])]);
    let v, prior, refs = {}, submission;
    try {
      v = controlledIntent(input);
      prior = await bounded(locate({identity: contentIdentity(v), correlation: v.correlation, binding: structuredClone(v.binding)}), signal);
      if (signal?.aborted) return unknown(refs, 'cancelled');
      if (prior?.outcome === 'found') {
        refs = structuredClone(prior.refs);
        await recover(refs.intent, v, 'intent', signal);
        // Even a retained success is re-observed; no local result cache authorizes continuation.
        if (refs.attempt) await recover(refs.attempt, v, 'attempt', signal);
        const result = refs.result ? await recover(refs.result, v, 'result', signal) : null;
        if (retryAfterNoEffect === true) {
          if (result?.outcome !== 'confirmed-no-effect' || result.submission?.diagnostic?.kind !== 'unauthorized'
              || !refs.attempt || !same(result.attempt, refs.attempt))
            return unknown(refs, 'unsafe-retry');
          refs.attempt = await retain(v, 'attempt', {previousResult: refs.result ?? null}, signal);
          submission = await bounded(authorization.request({...requestFor(v), context: structuredClone(v.binding), signal}), signal);
        }
      } else if (prior?.outcome === 'new' && prior.identity === contentIdentity(v)) {
        refs.intent = await retain(v, 'intent', {}, signal);
        if (signal?.aborted) return unknown(refs, 'cancelled');
        refs.attempt = await retain(v, 'attempt', {previousResult: refs.result ?? null}, signal);
        submission = await bounded(authorization.request({...requestFor(v), context: structuredClone(v.binding), signal}), signal);
      } else return unknown(refs, 'history');
      let observation;
      try {observation = await observe(provider, v, signal);} catch { /* Unknown effect remains blocked. */ }
      // Only the current boundary's explicit rejection BEFORE transport proves no effect.
      // HTTP failures, provider acknowledgment, cancellation and old state never do.
      const noEffect = submission?.outcome === 'failed' && submission.diagnostic?.kind === 'unauthorized';
      const outcome = observation ? 'confirmed-success' : noEffect ? 'confirmed-no-effect' : 'unknown';
      refs.result = await retain(v, 'result', {outcome, attempt: refs.attempt ?? null, observation: observation ?? null,
        submission: submission ? {outcome: submission.outcome, diagnostic: submission.diagnostic} : null}, signal);
      return {outcome, continuation: outcome === 'confirmed-success', refs,
        ...(observation ? {observation} : {})};
    } catch { return unknown(refs, 'identity-or-custody'); }
  }
  return Object.freeze({execute});
}
