const compareEndpointPattern = new RegExp(
  [
    String.raw`^\/repos\/[A-Za-z0-9_-]+\/[A-Za-z0-9_.-]+\/compare`,
    String.raw`\/[a-f0-9]{40}\.\.\.[a-f0-9]{40}$`,
  ].join(''),
);
const runnerPagePattern = new RegExp(
  [
    String.raw`\/actions\/(runners|runner-groups)(?:\/[1-9][0-9]*`,
    String.raw`\/(runners|repositories))?$`,
  ].join(''),
);
const dependenciesPattern = new RegExp(
  [
    String.raw`^\/repos\/[^/]+\/[^/]+\/issues\/[1-9][0-9]*\/dependencies`,
    String.raw`\/(blocked_by|blocking)$`,
  ].join(''),
);
const actionResourcePattern = new RegExp(
  [
    String.raw`^\/repos\/[^/]+\/[^/]+\/actions\/(?:runs\/[1-9][0-9]*(?:`,
    String.raw`\/(?:artifacts|attempts\/[1-9][0-9]*))?|artifacts`,
    String.raw`\/[1-9][0-9]*(?:\/zip)?)$`,
  ].join(''),
);
const runnerGroupPattern = new RegExp(
  [
    String.raw`^\/orgs\/[^/]+\/actions\/runner-groups(?:\/[1-9][0-9]*(?:`,
    String.raw`\/(runners|repositories))?)?$`,
  ].join(''),
);
const repositoryRunnerPattern = new RegExp(
  [
    String.raw`^\/repos\/[^/]+\/[^/]+\/actions\/runners(?:\/[1-9][0-9]*(?:`,
    String.raw`\/labels)?|\/(?:registration|remove)-token)?$`,
  ].join(''),
);
const organizationRunnerPattern = new RegExp(
  [
    String.raw`^\/orgs\/[^/]+\/actions\/runners(?:\/[1-9][0-9]*|`,
    String.raw`\/(?:registration|remove)-token)?$`,
  ].join(''),
);
import { GithubObservation } from './github.mjs';
import { setTimeout as sleep } from 'node:timers/promises';

import { githubApiVersion, origin, media } from './github-contract.mjs';
import { localGhTransport } from './github-transport.mjs';
import { githubRetryDelay } from './github-rate-limit.mjs';
export { githubApiVersion } from './github-contract.mjs';
export { localGhTransport } from './github-transport.mjs';
const writes = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);
const opaqueIdFields = new Set([
  'gravatar_id',
  'spdx_id',
  'external_id',
  'client_id',
  'tree_id',
]);
const token = (value) =>
  typeof value === 'string' && /^[a-zA-Z0-9_-]{1,80}$/.test(value);
const id = (value) => typeof value === 'string' && /^[1-9][0-9]*$/.test(value);
// Narrow read contracts used by authenticated recovery; query values never
// grant authority, select a checkout, or add a mutation capability.
function recoveryReadPermission(value) {
  if (typeof value !== 'string') return null;
  const [path, query, extra] = value.split('?');
  if (extra !== undefined) return null;
  const root = '/repos/[A-Za-z0-9_-]+/[A-Za-z0-9_.-]+';
  const matches = (tail) => new RegExp('^' + root + tail + '$').test(path);
  const params = new URLSearchParams(query),
    keys = [...params.keys()];
  if (new Set(keys).size !== keys.length) return null;
  if (matches('/actions/workflows/[1-9][0-9]*/runs')) {
    return keys.length > 0 &&
      params.get('event') === 'workflow_dispatch' &&
      keys.every(
        (k) =>
          k === 'event' ||
          (['page', 'per_page'].includes(k) &&
            /^[1-9][0-9]{0,5}$/.test(params.get(k))),
      ) &&
      (!params.has('per_page') || Number(params.get('per_page')) <= 100)
      ? 'actions:read'
      : null;
  }
  const pagination = () =>
    keys.every(
      (k) =>
        ['page', 'per_page'].includes(k) && /^[1-9][0-9]{0,5}$/.test(params.get(k)),
    ) &&
    (!params.has('per_page') || Number(params.get('per_page')) <= 100) &&
    query !== '';
  if (matches('/contents/\\.github/workflows/[A-Za-z0-9_-]+\\.ya?ml'))
    return keys.length === 1 &&
      keys[0] === 'ref' &&
      /^(?:main|[a-f0-9]{40})$/.test(params.get('ref'))
      ? 'contents:read'
      : null;
  if (matches('/commits/(?:main|[a-f0-9]{40})'))
    return query === undefined ? 'contents:read' : null;
  if (matches('/actions/workflows/[A-Za-z0-9_-]+\\.ya?ml'))
    return query === undefined ? 'actions:read' : null;
  if (matches('/actions/runs/[1-9][0-9]*/attempts/[1-9][0-9]*/jobs'))
    return pagination() ? 'actions:read' : null;
  if (matches('/check-runs/[1-9][0-9]*/annotations'))
    return pagination() ? 'checks:read' : null;
  if (matches('/actions/workflows/[A-Za-z0-9_-]+\\.ya?ml/runs')) {
    if (
      keys.some(
        (k) => !['event', 'status', 'created', 'per_page', 'page'].includes(k),
      ) ||
      !['event', 'status', 'created', 'per_page'].every((k) => params.has(k)) ||
      params.get('event') !== 'workflow_dispatch' ||
      params.get('status') !== 'completed' ||
      !/^([1-9]|[1-9][0-9]|100)$/.test(params.get('per_page')) ||
      (params.has('page') && !/^[12]$/.test(params.get('page')))
    )
      return null;
    const dates = params.get('created').split('..');
    if (
      dates.length !== 2 ||
      dates.some(
        (d) =>
          !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(d) ||
          !Number.isFinite(Date.parse(d)) ||
          new Date(d).toISOString() !== d,
      )
    )
      return null;
    const span = Date.parse(dates[1]) - Date.parse(dates[0]);
    return span >= 0 && span <= 86400000 ? 'actions:read' : null;
  }
  return null;
}
function endpoint(value) {
  if (recoveryReadPermission(value)) {
    const url = new URL(value, origin);
    if (
      url.pathname + url.search !== value ||
      url.pathname.split('/').some((p) => p === '.' || p === '..')
    )
      throw Error('unsupported');
    return value;
  }
  if (
    typeof value !== 'string' ||
    !/^\/(?:[a-zA-Z0-9_/?=&.-]|%2[fF])+$/.test(value) ||
    (value.includes('..') &&
      !(
        compareEndpointPattern.test(value) &&
        !value.split('/compare/')[0].includes('..')
      )) ||
    value.includes('//')
  )
    throw Error('unsupported');
  const url = new URL(value, origin);
  if (
    url.origin !== origin ||
    decodeURIComponent(url.pathname).includes('//') ||
    decodeURIComponent(url.pathname)
      .split('/')
      .some((part) => part === '.' || part === '..')
  )
    throw Error('unsupported');
  return url.pathname + url.search;
}
// Node 22's reviver source retains numeric spelling before lossy Number conversion.
export function parseGithubJson(text) {
  return JSON.parse(text, function (key, value, context) {
    const nodeId = key === 'node_id' || key.endsWith('_node_id');
    // Actions head_commit contains Git object hashes, not numeric resource IDs.
    const commitId =
      key === 'id' &&
      typeof value === 'string' &&
      /^[a-f0-9]{40}$/.test(value) &&
      typeof this.tree_id === 'string' &&
      /^[a-f0-9]{40}$/.test(this.tree_id);
    if (
      !commitId &&
      (key === 'id' || (key.endsWith('_id') && !nodeId && !opaqueIdFields.has(key)))
    ) {
      if (typeof value === 'number') value = context.source;
      // GitHub-hosted jobs use group 0 to denote no self-hosted runner group.
      if (
        value !== null &&
        !id(value) &&
        !(key === 'runner_group_id' && value === '0')
      )
        throw Error('identity');
    }
    if (
      nodeId &&
      (typeof value !== 'string' || !/^[A-Za-z0-9_=-]{1,256}$/.test(value))
    )
      throw Error('identity');
    return value;
  });
}

function classify(response) {
  if (response.failure)
    return ['authentication', 'malformed'].includes(response.failure)
      ? response.failure
      : 'transport';
  const { status, headers: h, body } = response;
  if (
    !Number.isInteger(status) ||
    status < 100 ||
    status > 599 ||
    typeof body !== 'string'
  )
    return 'malformed';
  if (status === 401) return 'authentication';
  if (
    (status === 403 || status === 429) &&
    (status === 429 ||
      h['x-ratelimit-remaining'] === '0' ||
      h['retry-after'] !== undefined ||
      /secondary rate limit/i.test(body))
  )
    return 'rate_limited';
  if (status === 403) return 'denied';
  if (status === 404) return 'not_found_or_inaccessible';
  if (status === 400 || status === 422) return 'invalid_request';
  if (status >= 500) return 'server';
  if (status < 200 || status >= 300) return 'unsupported';
  return null;
}
/** Official endpoint permission classes, not a statement that a token possesses them.
 * Unknown management endpoints are deliberately unsupported. */
export function githubEndpointPermission(method, endpoint) {
  if (typeof endpoint !== 'string') return null;
  if (/^\/repos\/[^/]+\/[^/]+\/actions\/runners\/generate-jitconfig$/.test(endpoint))
    return method === 'POST' ? 'administration:write' : null;
  if (method === 'GET' && recoveryReadPermission(endpoint))
    return recoveryReadPermission(endpoint);
  if (endpoint.includes('?')) {
    const [path, query, extra] = endpoint.split('?'),
      params = new URLSearchParams(query);
    const keys = [...params.keys()];
    if (
      method !== 'GET' ||
      extra !== undefined ||
      !keys.length ||
      new Set(keys).size !== keys.length ||
      keys.some(
        (k) =>
          !['page', 'per_page'].includes(k) ||
          !/^[1-9][0-9]{0,5}$/.test(params.get(k)),
      ) ||
      (params.has('per_page') && Number(params.get('per_page')) > 100) ||
      !(
        runnerPagePattern.test(path) ||
        /^\/repos\/[^/]+\/[^/]+\/actions\/runs\/[1-9][0-9]*\/artifacts$/.test(path) ||
        dependenciesPattern.test(path)
      )
    )
      return null;
    endpoint = path;
  }
  if (method === 'GET' && dependenciesPattern.test(endpoint)) return 'public:read';
  if (
    method === 'GET' &&
    (/^\/repos\/[^/]+\/[^/]+$/.test(endpoint) ||
      /^\/(users|orgs)\/[^/]+$/.test(endpoint))
  )
    return 'public:read';
  if (method === 'GET' && actionResourcePattern.test(endpoint)) return 'actions:read';
  if (
    method === 'POST' &&
    /^\/repos\/[^/]+\/[^/]+\/actions\/workflows\/[1-9][0-9]*\/dispatches$/.test(
      endpoint,
    )
  )
    return 'actions:write';
  if (
    method === 'GET' &&
    /^\/repos\/[^/]+\/[^/]+\/collaborators\/[^/]+\/permission$/.test(endpoint)
  )
    return 'metadata:read';
  if (method === 'GET' && runnerGroupPattern.test(endpoint))
    return 'organization_self_hosted_runners:read';
  if (repositoryRunnerPattern.test(endpoint)) {
    if (method === 'GET' && !endpoint.endsWith('-token'))
      return 'administration:read';
    if (
      (method === 'POST' && /\/(registration|remove)-token$/.test(endpoint)) ||
      (method === 'DELETE' && /\/runners\/[1-9][0-9]*$/.test(endpoint))
    )
      return 'administration:write';
    return null;
  }
  if (organizationRunnerPattern.test(endpoint)) {
    if (method === 'GET' && !endpoint.endsWith('-token'))
      return 'organization_self_hosted_runners:read';
    if (
      (method === 'POST' && /\/(registration|remove)-token$/.test(endpoint)) ||
      (method === 'DELETE' && /\/runners\/[1-9][0-9]*$/.test(endpoint))
    )
      return 'organization_self_hosted_runners:write';
    return null;
  }
  if (/^\/repos\/[^/]+\/[^/]+\/issues\/[1-9][0-9]*$/.test(endpoint))
    return method === 'GET'
      ? 'public:read'
      : method === 'PATCH'
        ? 'issues:write'
        : null;
  return null;
}

const requirement = (method, path) =>
  githubEndpointPermission(method, path) ?? 'unknown';

/** Transport and authorize are trusted Core capabilities, never provider data. */
export function createGithubProvider({
  transport,
  identity = 'local-stored-login',
  authorize,
  authorizeRead,
  now = Date.now,
  delay = (ms, signal) => sleep(ms, undefined, { signal }),
  attempts = 3,
  elapsedMs = 30000,
  maxPages = 100,
} = {}) {
  if (
    !['local-stored-login', 'hosted-authorized'].includes(identity) ||
    (transport !== undefined && typeof transport !== 'function') ||
    (identity === 'hosted-authorized' && !transport) ||
    (authorizeRead !== undefined && typeof authorizeRead !== 'function') ||
    !Number.isInteger(attempts) ||
    attempts < 1 ||
    attempts > 10 ||
    !Number.isInteger(elapsedMs) ||
    elapsedMs <= 0 ||
    elapsedMs > 86400000 ||
    !Number.isInteger(maxPages) ||
    maxPages < 1 ||
    maxPages > 1000
  )
    throw Error('Invalid provider configuration');
  transport ??= localGhTransport();
  const submissions = new WeakMap();
  const remaining = Symbol();
  const observations = new GithubObservation(performRequest);
  const request = (options) =>
    options[remaining] === undefined
      ? observations.request(options)
      : performRequest(options);
  async function performRequest(options) {
    let path,
      body,
      send = transport;
    let budget = options[remaining] ?? elapsedMs;
    const method = options.method ?? 'GET';
    const write = writes.has(method);
    let sent = false,
      started;
    const diagnostic = { kind: 'unsupported', capability: 'unknown' };
    const failure = (kind) => {
      const result = {
        outcome:
          write &&
          ['transport', 'server', 'malformed', 'timeout', 'cancelled'].includes(kind)
            ? 'unknown'
            : 'failed',
        diagnostic: { ...diagnostic, kind },
      };
      if (write && sent && result.outcome === 'unknown')
        submissions.set(result, { target: options.target, started });
      return result;
    };
    try {
      path = endpoint(options.endpoint);
      if (
        (!write && method !== 'GET') ||
        !token(options.operation) ||
        !token(options.correlation) ||
        !id(options.target)
      )
        return failure('unsupported');
      diagnostic.operation = options.operation;
      diagnostic.correlation = options.correlation;
      diagnostic.capability = requirement(method, path);
      body = options.body === undefined ? undefined : JSON.stringify(options.body);
      // Trusted transports may acquire a request-local credential before the
      // final authorization checkpoint. Never share prepared credentials across requests.
      if (write && typeof authorize !== 'function') return failure('unauthorized');
      if (!write && authorizeRead) {
        const readSignal = AbortSignal.any([
            AbortSignal.timeout(budget),
            ...(options.signal ? [options.signal] : []),
          ]),
          began = now();
        try {
          if (
            (await abortable(
              Promise.resolve(
                authorizeRead(
                  Object.freeze({
                    method,
                    endpoint: path,
                    operation: options.operation,
                    target: options.target,
                    correlation: options.correlation,
                    signal: readSignal,
                  }),
                ),
              ),
              readSignal,
            )) !== true
          )
            return failure('unauthorized');
        } catch {
          return failure(
            readSignal.aborted
              ? options.signal?.aborted
                ? 'cancelled'
                : 'timeout'
              : 'unauthorized',
          );
        }
        const used = now() - began;
        if (
          readSignal.aborted ||
          !Number.isSafeInteger(used) ||
          used < 0 ||
          used >= budget
        )
          return failure(options.signal?.aborted ? 'cancelled' : 'timeout');
        budget -= used;
      }
      if (write && typeof transport.prepareMutation === 'function') {
        const preparationSignal = AbortSignal.any([
          AbortSignal.timeout(budget),
          ...(options.signal ? [options.signal] : []),
        ]);
        send = await abortable(
          transport.prepareMutation({ signal: preparationSignal }),
          preparationSignal,
        );
        if (typeof send !== 'function' || preparationSignal.aborted)
          return failure('unauthorized');
      }
      if (
        write &&
        (typeof authorize !== 'function' ||
          (await authorize(
            Object.freeze({
              method,
              endpoint: path,
              operation: options.operation,
              target: options.target,
              context: options.context,
              correlation: options.correlation,
              signal: options.signal,
              body: body === undefined ? undefined : JSON.parse(body),
            }),
          )) !== true)
      )
        return failure('unauthorized');
    } catch {
      return failure('unsupported');
    }
    started = now();
    const signal = AbortSignal.any([
      AbortSignal.timeout(budget),
      ...(options.signal ? [options.signal] : []),
    ]);
    for (let attempt = 1; attempt <= (write ? 1 : attempts); attempt++) {
      if (signal.aborted)
        return failure(options.signal?.aborted ? 'cancelled' : 'timeout');
      if (now() - started >= budget) return failure('timeout');
      let response;
      try {
        sent = true;
        // Race also bounds an injected transport that ignores cancellation.
        response = await abortable(
          send({
            method,
            endpoint: path,
            body,
            signal,
            headers: { Accept: media, 'X-GitHub-Api-Version': githubApiVersion },
            ...(options.conditional === false ? { conditional: false } : {}),
            identity,
          }),
          signal,
        );
      } catch {
        response = { failure: 'transport' };
      }
      if (signal.aborted)
        return failure(options.signal?.aborted ? 'cancelled' : 'timeout');
      const headers = Object.fromEntries(
        Object.entries(response?.headers ?? {}).map(([k, v]) => [
          k.toLowerCase(),
          String(v),
        ]),
      );
      response = { ...response, headers };
      if (
        Number.isInteger(response.status) &&
        response.status >= 100 &&
        response.status <= 599
      )
        diagnostic.status = response.status;
      if (now() - started >= budget) return failure('timeout');
      if (token(headers['x-github-request-id']))
        diagnostic.requestId = headers['x-github-request-id'];
      const kind = classify(response);
      if (kind) {
        const result = failure(kind);
        if (write || !['transport', 'server', 'rate_limited'].includes(kind))
          return result;
        const wait = githubRetryDelay(
          headers,
          now(),
          attempt,
          kind === 'rate_limited',
        );
        if (Number.isFinite(wait)) result.diagnostic.retryAfterMs = wait;
        if (attempt === attempts || wait >= budget - (now() - started)) return result;
        try {
          await abortable(delay(wait, signal), signal);
        } catch {
          return failure(options.signal?.aborted ? 'cancelled' : 'timeout');
        }
        continue;
      }
      let data;
      try {
        data =
          response.status === 204 && response.body === ''
            ? null
            : parseGithubJson(response.body);
        if (
          (options.expectedId !== undefined &&
            (!id(options.expectedId) || data?.id !== options.expectedId)) ||
          (options.validate && options.validate(data) !== true)
        )
          return failure('malformed');
      } catch {
        return failure('malformed');
      }
      const result = {
        outcome: write ? 'submitted' : 'read',
        data,
        observedAt: now(),
        diagnostic: { ...diagnostic, kind: 'none' },
      };
      // Pagination metadata is trusted-only, excluded by publicDiagnostic.
      if (!write) result.link = headers.link;
      else submissions.set(result, { target: options.target, started });
      return result;
    }
  }
  async function collection(options) {
    const items = [],
      seen = new Set();
    const signal = AbortSignal.any([
      AbortSignal.timeout(elapsedMs),
      ...(options.signal ? [options.signal] : []),
    ]);
    const started = now();
    let path = options.endpoint;
    for (let page = 0; page < maxPages; page++) {
      if (
        seen.has(path) ||
        now() - started >= elapsedMs ||
        (options.allowPage && options.allowPage(path) !== true)
      )
        break;
      seen.add(path);
      const result = await request({
        ...options,
        method: 'GET',
        endpoint: path,
        signal,
        conditional: false,
        [remaining]: Math.max(1, elapsedMs - (now() - started)),
      });
      if (result.outcome !== 'read')
        return { ...publicDiagnostic(result), outcome: 'incomplete' };
      const values = options.envelope ? result.data?.[options.envelope] : result.data;
      const annotations =
        /^\/repos\/[^/]+\/[^/]+\/check-runs\/[1-9][0-9]*\/annotations(?:\?|$)/.test(
          path,
        );
      if (
        !Array.isArray(values) ||
        values.some(
          (value) =>
            !value ||
            (annotations
              ? !['notice', 'warning', 'failure'].includes(value.annotation_level) ||
                typeof value.message !== 'string'
              : !id(value.id)),
        )
      )
        return { outcome: 'incomplete', diagnostic: { kind: 'malformed' } };
      items.push(...values);
      if (!result.link) return { outcome: 'complete', data: items };
      try {
        const links = result.link.split(',').map((part) => {
          const match = part.trim().match(/^<([^>]+)>;\s*rel="([a-z]+)"$/);
          if (!match) throw Error('link');
          return match;
        });
        const next = links.filter((link) => link[2] === 'next');
        if (!next.length) return { outcome: 'complete', data: items };
        if (next.length !== 1) break;
        const url = new URL(next[0][1]);
        if (url.origin !== origin || url.username || url.password || url.hash) break;
        path = endpoint(url.pathname + url.search);
      } catch {
        break;
      }
    }
    return { outcome: 'incomplete', diagnostic: { kind: 'pagination' } };
  }
  async function reconcile(submission, options, matches) {
    const binding = submissions.get(submission);
    if (
      !binding ||
      options.target !== binding.target ||
      typeof matches !== 'function'
    )
      return { outcome: 'unknown' };
    const read = await observations.freshReadObservation(() =>
      request({ ...options, method: 'GET', body: undefined }),
    );
    try {
      if (
        read.outcome === 'read' &&
        read.observedAt >= binding.started &&
        read.data?.id === binding.target &&
        matches(read.data) === true
      )
        return { ...read, outcome: 'verified' };
    } catch {
      /* Caller predicates do not manufacture completion on failure. */
    }
    return { outcome: 'unknown', diagnostic: read.diagnostic };
  }
  return Object.freeze({
    request,
    collection,
    reconcile,
    readObservation: (work) => observations.readObservation(work),
    freshReadObservation: (work) => observations.freshReadObservation(work),
  });
}
function abortable(promise, signal) {
  return new Promise((resolve, reject) => {
    const abort = () => reject(Error('cancelled'));
    if (signal.aborted) return abort();
    signal.addEventListener('abort', abort, { once: true });
    Promise.resolve(promise)
      .then(resolve, reject)
      .finally(() => signal.removeEventListener('abort', abort));
  });
}
/** Publish only fixed-schema diagnostics. Data/link/context stay trusted-only. */
export function publicDiagnostic(result) {
  const d = result.diagnostic ?? {};
  return {
    outcome: result.outcome,
    diagnostic: Object.fromEntries(
      Object.entries(d).filter(
        ([key, value]) =>
          (['kind', 'capability'].includes(key) && /^[a-z_:]+$/.test(value)) ||
          (['operation', 'correlation', 'requestId'].includes(key) && token(value)) ||
          (['status', 'retryAfterMs'].includes(key) && Number.isFinite(value)),
      ),
    ),
  };
}
